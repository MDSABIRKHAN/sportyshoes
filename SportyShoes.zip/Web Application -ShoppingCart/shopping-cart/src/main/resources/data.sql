insert into user(id,first_name, last_name, mobile_no, date_of_birth, email_id,is_locked,password,invalid_attempts,login_count) 
	values(0,'Sabir', 'Khan', 6294993984L,'2000-05-05' ,'khansabir552000@gmail.com',false,'Khan.Sabir',0,0);
	

insert into credit_card(id,name, cc_number, month, year, cvv)
	values(52, 'Sabir Khan', 5000720014639381/ 7.0E0, 1, 2021,045);
insert into product(id,name,category,price,image) 
	values(1000,'Nike Air','Sports',12000,'1000.png');

insert into product(id,name,category,price,image) 
	values(1001,'Addidas Yezzy','Gym',10000,'1001.png');
	
insert into product(id,name,category,price,image) 
	values(1002,'Roadster','Casual',9000,'1002.png');

insert into product(id,name,category,price,image) 
	values(1003,'Puma Hell','Casual',12000,'1000.png');

insert into product(id,name,category,price,image) 
	values(1004,'Gucci','Gym',12000,'1001.png');
	
insert into product(id,name,category,price,image) 
	values(1005,'Nike Jordan','Sports',6000,'1002.png');

insert into product(id,name,category,price,image) 
	values(1006,'Roadster 5','Casual',10000,'1000.jpg');


;

	