package com.simplilearn.shoppingcart.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.simplilearn.shoppingcart.models.Cart;

public interface CartDao extends JpaRepository<Cart, Long> {

	List<Cart> findAllByUserId(Long userId);

	public void deleteAllById(Long id);
}
