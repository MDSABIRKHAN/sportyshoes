package com.simplilearn.shoppingcart.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.simplilearn.shoppingcart.models.User;
import com.simplilearn.shoppingcart.services.AdminService;
import com.simplilearn.shoppingcart.services.UserService;

@Controller
public class HomeController {

	@Autowired
	private UserService userService;
	@Autowired
	private AdminService adminService;

	public HomeController(UserService userService, AdminService adminService) {
		super();
		this.userService = userService;
		this.adminService = adminService;
	}

	@GetMapping("/error")
	public String error() {
		return "error";
	}

	@GetMapping("/")
	public String goHomePage(HttpSession session) {
		return getHomePage(session);
	}

	@GetMapping(value = "/home")
	public String getHomePage(HttpSession session) {
		Object attribute = session.getAttribute("attempt");

		if (attribute == null) {
			session.setAttribute("attempt", 0);
		}
		return "home";
	}

	@GetMapping("/register")
	public String getRegistrationPage() {
		return "register";
	}

	@PostMapping("/register")
	public String getHomeAfterSignup(User user, RedirectAttributes redirectAttributes) {

		if (this.userService.saveUser(user)) {
			redirectAttributes.addFlashAttribute("message",
					"Registration Successful ! Login Password is sent to your registered E-mail Id.");
		} else {
			redirectAttributes.addFlashAttribute("error", "Registration Failed! Duplicate Users not allowed");
		}
		return "redirect:/home";
	}

	@PostMapping("/login")
	public String doLogin(User user, HttpSession session, RedirectAttributes redirectAttributes) {

		if (user.getEmailId().equals("khansabir552000@gmail.com")) {// this is the preloaded record from data.sql(due to the
																// use of inmemory database)
			user = new User("Sabir", "Khan", 6294993984L, "05/05/2000", "khansabir552000@gmail.com"); // this.userService.getUser(user.getEmailId());

			user.setId(0L);
			session.setAttribute("loggedUser", user);
			if (user.getLoginCount() == 0) {
				return "redirect:/user/new-password";
			}
			session.removeAttribute("attempt");

			return "redirect:/user/welcome";
		} else if (this.userService.validateUser(user)) {// Database Validation
			user = this.userService.getUser(user.getEmailId());

			session.setAttribute("loggedUser", user);
			session.removeAttribute("attempt");
			if (user.getLoginCount() == 0) {
				return "redirect:/user/new-password";
			}

			return "redirect:/user/welcome";
		} else {
			// Counting login attempts
			user = userService.getUser(user.getEmailId());
			if (user != null) {
				int att = user.getInvalidAttempts();
				if (att >= 2) {// Account lock in 3 attempts
					redirectAttributes.addFlashAttribute("error", "Account Locked !");
					this.adminService.lockAccount(user.getEmailId());
					return "redirect:/home";
				}
				user.setInvalidAttempts(++att);
				userService.save(user);
				redirectAttributes.addFlashAttribute("error",
						"Invalid Credentials! " + (3 - att) + " Attempt(s) left.");
				return "redirect:/home";
			}
			redirectAttributes.addFlashAttribute("error", "Account Does Not Exists !");
			return "redirect:/home";

		}

	}

	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.removeAttribute("loggedUser");
		session.removeAttribute("attempt");
		return "redirect:/home";

	}

	@GetMapping("/admin")
	public String admin() {
		return "admin/adminlogin";
	}

	@PostMapping("/admin/admin")
	public String adminLogin(@RequestParam("password") String password, RedirectAttributes redirectAttributes) {
		if (!password.equalsIgnoreCase("password")) {

			redirectAttributes.addFlashAttribute("error", "Wrong Password");

			return "redirect:/admin";
		}
		return "admin/welcome";

	}
}
