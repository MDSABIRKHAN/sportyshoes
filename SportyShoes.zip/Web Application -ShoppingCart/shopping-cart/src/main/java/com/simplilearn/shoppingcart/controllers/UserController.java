package com.simplilearn.shoppingcart.controllers;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.simplilearn.shoppingcart.models.Cart;
import com.simplilearn.shoppingcart.models.CreditCard;
import com.simplilearn.shoppingcart.models.Product;
import com.simplilearn.shoppingcart.models.PurchaseRecord;
import com.simplilearn.shoppingcart.models.User;
import com.simplilearn.shoppingcart.services.UserService;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	UserService userService;
	

	public UserController(UserService userService) {
		super();
		this.userService = userService;
	}

	/*
	 * @GetMapping("/products") public ModelAndView getProducts() { ModelAndView mv
	 * = new ModelAndView(); List<Product> list = userService.getAllProducts();
	 * mv.addObject("list", list); mv.setViewName("user/products"); return mv;
	 * 
	 * }
	 */
	@GetMapping("/welcome")
	public String welcome() {
//		User user = (User) session.getAttribute("loggedUser");
		return "welcome";
	}

	@GetMapping("/new-password")
	public String newPassword() {
//		User user = (User) session.getAttribute("loggedUser");
		return "change-password";
	}

	@PostMapping("/change-password")
	public String changePassword(@RequestParam("newPassword") String newPassword,
			@RequestParam("confirmPassword") String confirmPassword, HttpSession session,
			RedirectAttributes redirectAttributes) {
		if (newPassword.equals(confirmPassword)) {
			User user = (User) session.getAttribute("loggedUser");
			user.setPassword(this.userService.generateEncryptedPassword(newPassword));
			user.setLoginCount(user.getLoginCount() + 1);
			user = this.userService.save(user);
//			System.out.println(user);
			return "redirect:/user/welcome";
		}
		redirectAttributes.addFlashAttribute("error", "Password Does not match. Try Again !");
		return "redirect:/user/new-password";

	}

	@GetMapping("/products/{pageNo}")
	public ModelAndView getProductWithPagination(@PathVariable("pageNo") int pageNo,
			@RequestParam("sortField") String sortField, @RequestParam("sortDir") String sortDir) {
		ModelAndView mv = new ModelAndView();
		int productPerPage = 4;
		Page<Product> page = this.userService.getAllProducts(pageNo, productPerPage, sortField, sortDir);

		mv.addObject("pageNo", pageNo);
		mv.addObject("pageCount", page.getTotalPages());

		mv.addObject("sortField", sortField);
		mv.addObject("sortDir", sortDir);
		mv.addObject("reverseSortDir", sortDir.equals("asc") ? "desc" : "asc");

		mv.addObject("list", page.getContent());
		mv.setViewName("user/products");
		return mv;

	}

	@GetMapping("/add-to-cart/{id}")
	public String addToCart(@PathVariable("id") Long id, HttpSession session, RedirectAttributes redirectAttributes) {

		Product product = this.userService.findProductById(id);
		User user = (User) session.getAttribute("loggedUser");

		Cart cart = new Cart(user.getId(), product.getId(), product.getName(), product.getPrice());
		cart = this.userService.saveCart(cart);

		if (cart != null) {
			redirectAttributes.addFlashAttribute("message", product.getName() + " added to your cart successfully");
		} else {
			redirectAttributes.addFlashAttribute("error", " Unable to add. Try Again !");
		}
		return "redirect:/user/products/1?sortField=name&sortDir=asc";

	}

	@GetMapping("/cart")
	public ModelAndView showCart(HttpSession session) {

		ModelAndView modelAndView = new ModelAndView("user/cart");

		User user = (User) session.getAttribute("loggedUser");
		List<Cart> cart = this.userService.getCart(user.getId());

		if (cart.isEmpty()) {
			modelAndView.addObject("error", "Cart is Empty !");
		} else {
			modelAndView.addObject("cart", cart);
			BigDecimal totalPrice = this.userService.getTotal(cart);

			modelAndView.addObject("totalPrice", totalPrice);
		}
		return modelAndView;

	}

	@GetMapping("/cart/remove-item/{id}")
	public String removeItem(@PathVariable("id") Long id) {
		this.userService.removeItem(id);
		return "redirect:/user/cart";
	}

	@GetMapping("/payment")
	public String payment() {
		return "user/payment";

	}

	@PostMapping("/order-status")
	public ModelAndView paymentSuccess(CreditCard creditCard, HttpSession session, RedirectAttributes redirectAttributes) {
		ModelAndView modelAndView = new ModelAndView("user/order-detail");
		if (this.userService.validateCC(creditCard) == null) {
			modelAndView.setViewName("redirect:/user/payment");
			redirectAttributes.addFlashAttribute("error",
					"Payment Failed. Invalid Credentials !");
		}else {

		User user = (User) session.getAttribute("loggedUser");
		List<Cart> cart = this.userService.getCart(user.getId());
		BigDecimal totalPrice = this.userService.getTotal(cart);

		PurchaseRecord purchaseRecord = this.userService.savePurchase(new PurchaseRecord(user.getId(), totalPrice));
		purchaseRecord.setProducts(this.userService.getProductsFromCart(cart));

		modelAndView.addObject("purchaseRecord", purchaseRecord);
		this.userService.clearCart(cart);
		}
		return modelAndView;

	}

	@GetMapping("/purchase-history/{pageNo}")
	public ModelAndView getPurchaseHistory(HttpSession session, @PathVariable("pageNo") int pageNo,
			@RequestParam("sortField") String sortField, @RequestParam("sortDir") String sortDir) {
		User user = (User) session.getAttribute("loggedUser");
		int recordPerPage = 2;
		Page<PurchaseRecord> page = this.userService.getPurchaseHistoryForUser(user.getId(), pageNo, recordPerPage,
				sortField, sortDir);
		ModelAndView mv = new ModelAndView("user/purchase-history");

		mv.addObject("pageNo", pageNo);
		mv.addObject("pageCount", page.getTotalPages());

		mv.addObject("sortField", sortField);
		mv.addObject("sortDir", sortDir);
		mv.addObject("reverseSortDir", sortDir.equals("asc") ? "desc" : "asc");

		mv.addObject("list", page.getContent());
		return mv;

	}

	@GetMapping("/purchase-history/record/{id}")
	public ModelAndView getPurchaseRecord(@PathVariable("id") Long id, HttpSession session) {

		PurchaseRecord purchaseRecord = this.userService.getRecordById(id);

		ModelAndView modelAndView = new ModelAndView("user/order-detail");
		modelAndView.addObject("purchaseRecord", purchaseRecord);

		return modelAndView;

	}

	@GetMapping("/my-profile")
	public String showProfile() {
		return "user/my-profile";

	}

	@PostMapping("/my-profile")
	public String updateProfile(User user, HttpSession session) {

		user = this.userService.save(user);

		session.removeAttribute("loggedUser");
		session.setAttribute("loggedUser", user);

		return "redirect:/user/my-profile";

	}

	@GetMapping("/purchase-history.xlsx")
	public ResponseEntity<InputStreamResource> exportPurchaseHistory(HttpSession session) throws IOException {

		User user = (User) session.getAttribute("loggedUser");

		List<PurchaseRecord> purchaseHistory = this.userService.getPurchaseHistoryForUser(user.getId());
		ByteArrayInputStream in = this.userService.getPurchaseHistory(purchaseHistory);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=PurchaseHistory-" + new Date() + ".xlsx");

		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));

	}

}
