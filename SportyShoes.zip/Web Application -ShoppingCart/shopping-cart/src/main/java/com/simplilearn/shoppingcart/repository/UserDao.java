package com.simplilearn.shoppingcart.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.simplilearn.shoppingcart.models.User;

public interface UserDao  extends JpaRepository<User, Long>{

	public User findByEmailIdAndPassword(String emailId, String password);

	public boolean existsByEmailId(String emailId);

	public User findByMobileNo(Long mobileNo);

	public boolean existsByMobileNo(Long mobileNo);

	public boolean existsByEmailIdAndPassword(String emailId, String password);

	public User findByEmailId(String emailId);


	 
	
}
