package com.simplilearn.shoppingcart.models;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;

import org.hibernate.annotations.CreationTimestamp;

@Entity
public class PurchaseRecord {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "confirmation_number")
	@SequenceGenerator(name = "confirmation_number", initialValue = 4000000)
	private Long confirmationNumber;
	private Long userId;
	@CreationTimestamp
	private Date purchaseDate;
	private BigDecimal price;
	@ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "PURCHASE_RECORD_PRODUCT", 
             joinColumns = { @JoinColumn(name = "PURCHASE_RECORD_CONFIRMATION_NUMBER") }, 
             inverseJoinColumns = { @JoinColumn(name = "PRODUCT_ID") })
	private List<Product> products = new ArrayList<>();
	protected PurchaseRecord() {
		super();
	}
	public PurchaseRecord(Long userId, BigDecimal price) {
		super();
		this.userId = userId;
		this.price = price;
	}
	public Long getConfirmationNumber() {
		return confirmationNumber;
	}
	public void setConfirmationNumber(Long confirmationNumber) {
		this.confirmationNumber = confirmationNumber;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Date getPurchaseDate() {
		return purchaseDate;
	}
	
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	
	public List<Product> getProducts() {
		return products;
	}
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	@Override
	public String toString() {
		return "PurchaseRecord [confirmationNumber=" + confirmationNumber + ", userId=" + userId + ", purchaseDate="
				+ purchaseDate + ", price=" + price + ", products=" + products + "]";
	}
	
	
	
}
