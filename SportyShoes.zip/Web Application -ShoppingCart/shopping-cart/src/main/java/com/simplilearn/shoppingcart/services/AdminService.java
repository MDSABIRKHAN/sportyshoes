/**
 * 
 */
package com.simplilearn.shoppingcart.services;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.simplilearn.shoppingcart.models.Product;
import com.simplilearn.shoppingcart.models.User;

/**
 * @author Parag Bajaj
 *
 */
public interface AdminService {

	

	List<User> getAllUsers();

	List<Product> getAllProducts();

	void updateAccount(Long id);

	void lockAccount(String emailId);
	
	String uploadImage(MultipartFile file) throws IOException;

	ByteArrayInputStream exportProducts() throws Exception;

	void addNewProduct(Product product, MultipartFile file) throws Exception;
	
	
}
