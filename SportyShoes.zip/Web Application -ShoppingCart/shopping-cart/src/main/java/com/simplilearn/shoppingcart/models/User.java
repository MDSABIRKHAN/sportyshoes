package com.simplilearn.shoppingcart.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	private String firstName;
	private String lastName;
	private Long mobileNo;
	private String dateOfBirth;
	private String emailId;
	private String password;
	private Boolean isLocked;
	private int invalidAttempts;
	private int loginCount;
	private String roles;

	protected User() {

	}

	public User(String firtsName, String lastName, Long mobileNo, String dateOfBirth, String email) {
		super();

		this.firstName = firtsName;
		this.lastName = lastName;
		this.mobileNo = mobileNo;
		this.dateOfBirth = dateOfBirth;
		this.emailId = email;
	}

	public Long getId() {
		return id;
	}



	public String getRoles() {
		return roles;
	}

	public void setRoles(String roles) {
		this.roles = roles;
	}

	public String getFirstName() {
		return firstName;
	}



	public String getLastName() {
		return lastName;
	}


	public Long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}



	public String getEmailId() {
		return emailId;
	}



	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Boolean getIsLocked() {
		return isLocked;
	}

	public void setIsLocked(Boolean isLocked) {
		this.isLocked = isLocked;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	

	public int getInvalidAttempts() {
		return invalidAttempts;
	}

	public void setInvalidAttempts(int invalidAttempts) {
		this.invalidAttempts = invalidAttempts;
	}

	public int getLoginCount() {
		return loginCount;
	}

	public void setLoginCount(int loginCount) {
		this.loginCount = loginCount;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", mobileNo=" + mobileNo
				+ ", dateOfBirth=" + dateOfBirth + ", emailId=" + emailId + ", password=" + password + ", isLocked="
				+ isLocked + "]";
	}

	public void setId(Long id) {
		this.id = id;
	}

	

	

	

}
