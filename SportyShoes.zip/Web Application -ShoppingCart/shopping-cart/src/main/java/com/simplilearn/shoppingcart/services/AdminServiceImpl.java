package com.simplilearn.shoppingcart.services;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.simplilearn.shoppingcart.models.Product;
import com.simplilearn.shoppingcart.models.User;
import com.simplilearn.shoppingcart.repository.ProductDao;
import com.simplilearn.shoppingcart.repository.UserDao;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

/**
 * @author Parag Bajaj
 *
 */
@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	UserDao userDao;

	@Autowired
	ProductDao productDao;

	@Override
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return userDao.findAll();
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return productDao.findAll();
	}

	@Override
	public void updateAccount(Long id) {
		// TODO Auto-generated method stub
		User user = userDao.findById(id).orElse(null);
		user.setIsLocked(!user.getIsLocked());
		userDao.saveAndFlush(user);
	}

	@Override
	public void lockAccount(String emailId) {
		// TODO Auto-generated method stub
		userDao.findByEmailId(emailId).setIsLocked(true);
		userDao.flush();

	}

	@Override
	public String uploadImage(MultipartFile file) throws IOException {
		// TODO Auto-generated method stub
		String folder = "/img/";
		byte[] bytes = file.getBytes();
		Path path = Paths.get(folder + file.getOriginalFilename());
		Files.write(path, bytes);
		return file.getOriginalFilename();
	}

	@Override
	public ByteArrayInputStream exportProducts() throws Exception {
		// TODO Auto-generated method stub
		String[] COLUMNs = { "ID", "Name", "Price", "Category" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			Sheet sheet = workbook.createSheet("Purchase Record");
			// Row for Header
			Row headerRow = sheet.createRow(0);
			// Header
			for (int col = 0; col < COLUMNs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(COLUMNs[col]);
			}
			int rowIdx = 1;
			List<Product> allProducts = getAllProducts();
			for (Product product : allProducts) {
				Row row = sheet.createRow(rowIdx++);
				// "Confirmation Number", "Date", "Total", "Product's Name","Product's Price"
				row = sheet.createRow(rowIdx++);
				row.createCell(0).setCellValue(product.getId());
				row.createCell(1).setCellValue(product.getName());
				row.createCell(2).setCellValue(product.getPrice().toString());
				row.createCell(3).setCellValue(product.getCategory());
			}
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		}

	}

	@Override
	public void addNewProduct(Product product, MultipartFile file) throws Exception {
		// TODO Auto-generated method stub
		product = productDao.save(product);
		product.setImage(uploadImage(file, product.getId().toString()));
		productDao.flush();
	}

	private String uploadImage(MultipartFile file, String filename) throws Exception {

		var is = file.getInputStream();
		String[] type = file.getOriginalFilename().split("\\.");
		filename += type[type.length - 1];
		String path = "src/main/webapp/img/";
		try {
			Files.copy(is, Paths.get(path + filename), // path+filename
					StandardCopyOption.REPLACE_EXISTING);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return filename;
	}

}
