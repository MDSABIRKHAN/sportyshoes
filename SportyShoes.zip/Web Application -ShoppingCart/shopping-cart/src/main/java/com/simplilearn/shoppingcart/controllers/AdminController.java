
package com.simplilearn.shoppingcart.controllers;

import java.io.ByteArrayInputStream;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.simplilearn.shoppingcart.models.Product;
import com.simplilearn.shoppingcart.models.PurchaseRecord;
import com.simplilearn.shoppingcart.services.AdminService;
import com.simplilearn.shoppingcart.services.UserService;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	AdminService adminService;
	@Autowired
	UserService userService;
	

	public AdminController(AdminService adminService, UserService userService) {
		super();
		this.adminService = adminService;
		this.userService = userService;
	}

	@GetMapping("/user-management")
	public ModelAndView userData() {
		ModelAndView modelAndView = new ModelAndView("admin/user-management");
		modelAndView.addObject("list", this.adminService.getAllUsers());
		
		return modelAndView;

	}

	@GetMapping("/product-management/{pageNo}")
	public ModelAndView productData(@PathVariable("pageNo") int pageNo,
			@RequestParam("sortField") String sortField, @RequestParam("sortDir") String sortDir) {
		ModelAndView mv = new ModelAndView();
		int productPerPage = 4;
		
		Page<Product> page = this.userService.getAllProducts(pageNo, productPerPage, sortField, sortDir);
		
		mv.addObject("pageNo", pageNo);
		mv.addObject("pageCount", page.getTotalPages());
		
		mv.addObject("sortField", sortField);
		mv.addObject("sortDir", sortDir);
		mv.addObject("reverseSortDir", sortDir.equals("asc") ? "desc" : "asc");

		mv.addObject("list", page.getContent());
		mv.setViewName("admin/product-management");
		
		return mv;


	}

	@GetMapping("/user/updated-status/{id}")
	public String updateAccount(@PathVariable("id") Long id) {
		
		this.adminService.updateAccount(id);
		
		return "redirect:/admin/user-management";

	}

	@GetMapping("/user/purchase-history/{id}")
	public ModelAndView getPurchaseHistory(@PathVariable("id") Long id) {
		
		List<PurchaseRecord> list = this.userService.getPurchaseHistoryForUser(id);
		
		ModelAndView modelAndView = new ModelAndView("admin/purchase-history");
		modelAndView.addObject("list", list);
		
		return modelAndView;

	}

	@GetMapping("/purchase-record/{id}")
	public ModelAndView getPurchaseRecord(@PathVariable("id") Long id) {
		PurchaseRecord purchaseRecord = this.userService.getRecordById(id);
		
		ModelAndView modelAndView = new ModelAndView("admin/order-detail");
		modelAndView.addObject("purchaseRecord", purchaseRecord);
		
		return modelAndView;

	}

	@PostMapping("/user-management")
	public String name() {
		return "admin/user-management";

	}

	@GetMapping("/export")
	public ResponseEntity<InputStreamResource> exportToExcel() throws Exception {
		
		HttpHeaders headers = new HttpHeaders();
		
		ByteArrayInputStream in = this.adminService.exportProducts();		
		headers.add("Content-Disposition", "attachment; filename=Products-" + new Date() + ".xlsx");
		
		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	@PostMapping(value = "/upload-product", consumes = { "multipart/form-data" })
	public String addNewProduct(@RequestParam MultipartFile file,Product product) throws Exception {

		this.adminService.addNewProduct(product,file);
		
		return "redirect:/admin/product-management";
	}

	
}
