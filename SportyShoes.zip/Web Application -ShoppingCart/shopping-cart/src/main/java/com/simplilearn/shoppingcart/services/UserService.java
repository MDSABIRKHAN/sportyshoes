
/**
 * 
 */
package com.simplilearn.shoppingcart.services;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.data.domain.Page;

import com.simplilearn.shoppingcart.models.Cart;
import com.simplilearn.shoppingcart.models.CreditCard;
import com.simplilearn.shoppingcart.models.Product;
import com.simplilearn.shoppingcart.models.PurchaseRecord;
import com.simplilearn.shoppingcart.models.User;

/**
 * @author Parag Bajaj
 *
 */
public interface UserService {

	public boolean saveUser(User user);
	public String generateEncryptedPassword(String password);

	public boolean validateUser(User user);

	public User getUser(String emailId);


	public Page<Product> getAllProducts(int pageNo, int pageSize, String sortField, String sortDirection);

	public List<Cart> getCart(Long id);

	public Product findProductById(Long id);

	public Cart saveCart(Cart cart);

	public BigDecimal getTotal(List<Cart> cart);

	public CreditCard saveCreditCard(CreditCard creditCard);

	public PurchaseRecord savePurchase(PurchaseRecord purchaseRecord);

	public void removeItem(Long id);

	public void clearCart(List<Cart> products);

	public Page<PurchaseRecord> getPurchaseHistoryForUser(Long id, int pageNo, int recordPerPage, String sortField, String sortDir);

	public List<Product> getProductsFromCart(List<Cart> cart);

	public PurchaseRecord getRecordById(Long id);

	void sendmail(String message, String email) throws AddressException, MessagingException, IOException;

	public ByteArrayInputStream getPurchaseHistory(List<PurchaseRecord> purchaseHistory) throws IOException;


	public List<PurchaseRecord> getPurchaseHistoryForUser(Long id);

	public User save(User user);
	public CreditCard validateCC(CreditCard creditCard);

	

}
