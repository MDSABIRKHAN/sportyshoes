package com.simplilearn.shoppingcart.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import org.hibernate.annotations.ColumnTransformer;

@Entity
public class CreditCard {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cc_id")
	@SequenceGenerator(name = "cc_id", initialValue = 2000)
	private Long id;
//	private Long userId;
	private String name;
//	@ColumnTransformer(read="decrypt(credit_card_num)" ,write="encrypt(?)")
//	@ColumnTransformer(read = "AES_DECRYPT(UNHEX(gmailAddress), 'mySecretKey')",
//			write = "HEX(AES_ENCRYPT(?, 'mySecretKey'))")
//	@ColumnTransformer(read = "AES_ENCRYPT('ccNumber',UNHEX('F3229A0B371ED2D9441B830D21A390C3'))",
//			write = "AES_ENCRYPT('?',UNHEX('F3229A0B371ED2D9441B830D21A390C3'))")
//	@ColumnTransformer(
//            read = "DECRYPT('AES', 123456, cc_number)",
//            write = "ENCRYPT('AES', 123456, ?)"
//    )
	@ColumnTransformer( read = "cc_number * 7.0E0", write = "? / 7.0E0")
	private Long ccNumber;
	private Integer month;
	private Integer year;
	
	private Integer cvv;

	protected CreditCard() {
		super();
	}

	public CreditCard( String name, Long ccNumber, Integer month, Integer year, Integer cvv) {
		super();
		
//		this.userId = userId;
		this.name = name;
		this.ccNumber = ccNumber;
		this.month = month;
		this.year = year;
		this.cvv = cvv;
	}
//	public Long getUserId() {
//		return userId;
//	}

	public String getName() {
		return name;
	}

	public Long getCcNumber() {
		return ccNumber;
	}

	public Integer getMonth() {
		return month;
	}

	public Integer getYear() {
		return year;
	}

	public Integer getCvv() {
		return cvv;
	}

	public Long getId() {
		return id;
	}

	public void setCcNumber(Long ccNumber) {
		this.ccNumber = ccNumber;
	}

	// public void setUserId(Long userId) {
//		this.userId = userId;
//		
//	}
	@Override
	public String toString() {
		return "CreditCard [id=" + id + ", name=" + name + ", ccNumber=" + ccNumber + ", month=" + month + ", year="
				+ year + ", cvv=" + cvv + "]";
	}

}
