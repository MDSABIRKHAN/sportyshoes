package com.simplilearn.shoppingcart.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.simplilearn.shoppingcart.models.CreditCard;

public interface CreditCardDao extends JpaRepository<CreditCard, Long> {

	CreditCard findByCcNumberAndCvv(Long ccNumber, Integer cvv);

}
