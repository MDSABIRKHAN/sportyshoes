
package com.simplilearn.shoppingcart.models;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Cart {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE , generator = "cart_id")
	@SequenceGenerator(name = "cart_id", initialValue = 3000)
	private Long id;
	private Long productId;
	private String productName;
	private BigDecimal productPrice;
	
	private Long userId;

	protected Cart() {

	}


	public Cart(Long userId ,Long productId, String productName, BigDecimal productPrice) {
		super();
		this.userId = userId;
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
	}


	public Long getUserId() {
		return userId;
	}


	public void setUserId(Long userId) {
		this.userId = userId;
	}


	public Long getId() {
		return id;
	}



	public Long getProductId() {
		return productId;
	}


	public void setProductId(Long productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public BigDecimal getProductPrice() {
		return productPrice;
	}


	@Override
	public String toString() {
		return "Cart [id=" + id + ", productId=" + productId + ", productName=" + productName + ", productPrice="
				+ productPrice + ", userId=" + userId + "]";
	}





	

	

}
