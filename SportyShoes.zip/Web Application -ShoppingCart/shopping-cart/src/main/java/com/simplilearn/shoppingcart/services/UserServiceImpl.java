package com.simplilearn.shoppingcart.services;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jasypt.util.password.StrongPasswordEncryptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.simplilearn.shoppingcart.models.Cart;
import com.simplilearn.shoppingcart.models.CreditCard;
import com.simplilearn.shoppingcart.models.Product;
import com.simplilearn.shoppingcart.models.PurchaseRecord;
import com.simplilearn.shoppingcart.models.User;
import com.simplilearn.shoppingcart.repository.CartDao;
import com.simplilearn.shoppingcart.repository.CreditCardDao;
import com.simplilearn.shoppingcart.repository.ProductDao;
import com.simplilearn.shoppingcart.repository.PurchaseRecordDao;
import com.simplilearn.shoppingcart.repository.UserDao;
import com.simplilearn.shoppingcart.resources.PasswordGenerator;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao userDao;

	@Autowired
	ProductDao productDao;

	@Autowired
	CartDao cartDao;
	@Autowired
	CreditCardDao creditCardDao;

	@Autowired
	PurchaseRecordDao purchaseRecordDao;

	@Autowired
	StrongPasswordEncryptor encryptor;
	
	@Autowired
	PasswordGenerator pwdGenerator;

	@Override
	public boolean saveUser(User user) {
		// TODO Auto-generated method stub
		if (userDao.existsByEmailId(user.getEmailId()) || userDao.existsByMobileNo(user.getMobileNo())) {
			return false;
		}
		String password = pwdGenerator.generatePassword();
		user.setPassword(generateEncryptedPassword(password));
		user.setIsLocked(false);
		try {
			sendmail(password, user.getEmailId());
		} catch (Exception e) {
			// TODO Auto-generated catch block
		}
		user.setInvalidAttempts(0);
		user.setLoginCount(0);
		userDao.saveAndFlush(user);
		return true;
	}
	@Override
	public String generateEncryptedPassword(String password) {
		// TODO Auto-generated method stub
		return encryptor.encryptPassword(password);
	}

	@Override
	public boolean validateUser(User user) {
		// TODO Auto-generated method stub
		if (userDao.existsByEmailId(user.getEmailId())) {
			System.out.println("emailchecked");
			if (!userDao.findByEmailId(user.getEmailId()).getIsLocked()) {
				System.out.println("locking checked");
				if (checkPassword(user, user.getPassword())) {
					System.out.println("passwordcheck");
					return true;
				}
			}
		}
		return false;

	}

	private boolean checkPassword(User user, String password) {
		// TODO Auto-generated method stub
		return encryptor.checkPassword(password, userDao.findByEmailId(user.getEmailId()).getPassword());
	}

	@Override
	public User getUser(String emailId) {
		// TODO Auto-generated method stub
		return userDao.findByEmailId(emailId);
	}

	@Override
	public Page<Product> getAllProducts(int pageNo, int pageSize, String sortField, String sortDirection) {
		// TODO Auto-generated method stub
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
				: Sort.by(sortField).descending();

		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
		return productDao.findAll(pageable);
	}

	@Override
	public List<Cart> getCart(Long id) {
		// TODO Auto-generated method stub
		return cartDao.findAllByUserId(id);
	}

	@Override
	public Product findProductById(Long id) {
		// TODO Auto-generated method stub
		return productDao.findById(id).orElse(null);
	}

	@Override
	public Cart saveCart(Cart cart) {
		// TODO Auto-generated method stub
		return cartDao.saveAndFlush(cart);
	}

	@Override
	public BigDecimal getTotal(List<Cart> cart) {
		// TODO Auto-generated method stub
		return cart.stream().map(pro -> pro.getProductPrice()).reduce(new BigDecimal(0), (a, b) -> a.add(b));
	}

	@Override
	public CreditCard saveCreditCard(CreditCard creditCard) {
		// TODO Auto-generated method stub
		return creditCardDao.save(creditCard);
	}

	@Override
	public PurchaseRecord savePurchase(PurchaseRecord purchaseRecord) {
		// TODO Auto-generated method stub
		return purchaseRecordDao.saveAndFlush(purchaseRecord);
	}

	@Override
	public void clearCart(List<Cart> cart) {
		// TODO Auto-generated method stub
		cartDao.deleteAll(cart);
	}

	@Override
	public Page<PurchaseRecord> getPurchaseHistoryForUser(Long id, int pageNo, int recordPerPage, String sortField,
			String sortDir) {
		// TODO Auto-generated method stub
		Sort sort = sortDir.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending()
				: Sort.by(sortField).descending();

		Pageable pageable = PageRequest.of(pageNo - 1, recordPerPage, sort);
		return purchaseRecordDao.findByUserId(id, pageable);
	}

	@Override
	public List<Product> getProductsFromCart(List<Cart> cart) {
		// TODO Auto-generated method stub
		return cart.stream().map(cartItem -> productDao.findById(cartItem.getProductId()).orElse(null))
				.collect(Collectors.toList());
	}

	@Override
	public PurchaseRecord getRecordById(Long id) {
		// TODO Auto-generated method stub
		return purchaseRecordDao.findById(id).orElse(null);
	}

	@Override
	public void sendmail(String message, String email) throws AddressException, MessagingException, IOException {
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("pparag68@gmail.com", "Parag@1234");
			}
		});
		Message msg = new MimeMessage(session);
		msg.setFrom(new InternetAddress("pparag68@gmail.com", false));

		msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email));
		msg.setSubject("Password for S-Cart ");
		msg.setContent(message, "text/html");
		msg.setSentDate(new Date());

		MimeBodyPart messageBodyPart = new MimeBodyPart();
		messageBodyPart.setContent(message, "text/html");

//		Multipart multipart = new MimeMultipart();
//		multipart.addBodyPart(messageBodyPart);
//		MimeBodyPart attachPart = new MimeBodyPart();

//		attachPart.attachFile("/var/tmp/image19.png");
//		multipart.addBodyPart(attachPart);
//		msg.setContent(multipart);
		Transport.send(msg);
	}

	@Override
	public ByteArrayInputStream getPurchaseHistory(List<PurchaseRecord> purchaseHistory) throws IOException {
		// TODO Auto-generated method stub
		String[] COLUMNs = { "Confirmation Number", "Date", "Total", "Product's Name", "Product's Price" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			Sheet sheet = workbook.createSheet("Purchase Record");
			// Row for Header
			Row headerRow = sheet.createRow(0);
			// Header
			for (int col = 0; col < COLUMNs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(COLUMNs[col]);
			}
			int rowIdx = 1;
			for (PurchaseRecord purchaseRecord : purchaseHistory) {

				Row row = sheet.createRow(rowIdx++);

//				"Confirmation Number", "Date", "Total", "Product's Name","Product's Price"
				row.createCell(0).setCellValue(purchaseRecord.getConfirmationNumber());
				row.createCell(1).setCellValue(purchaseRecord.getPurchaseDate());
				row.createCell(2).setCellValue(purchaseRecord.getPrice().toString());

				List<Product> products = purchaseRecord.getProducts();
				row.createCell(3).setCellValue(products.get(0).getName());
				row.createCell(4).setCellValue(products.get(0).getCategory());
				row.createCell(5).setCellValue(products.get(0).getPrice().toString());

				if (products.size() > 0) {
					for (int i = 1; i < products.size(); i++) {

						row = sheet.createRow(rowIdx++);

						row.createCell(3).setCellValue(products.get(i).getName());
						row.createCell(4).setCellValue(products.get(i).getCategory());
						row.createCell(5).setCellValue(products.get(i).getPrice().toString());
					}
				}
				rowIdx++;
			}
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	@Override
	public void removeItem(Long id) {
		// TODO Auto-generated method stub
		cartDao.deleteById(id);
		cartDao.flush();
	}

	@Override
	public List<PurchaseRecord> getPurchaseHistoryForUser(Long id) {
		// TODO Auto-generated method stub
		return purchaseRecordDao.findAllByUserId(id);
	}

	@Override
	public User save(User user) {
		// TODO Auto-generated method stub
		return userDao.save(user);
	}
	@Override
	public CreditCard validateCC(CreditCard creditCard) {
		// TODO Auto-generated method stub
		System.out.println(creditCardDao.findById(52L).toString());
		return creditCardDao.findByCcNumberAndCvv(creditCard.getCcNumber(),creditCard.getCvv()) ;
		
	}
}
