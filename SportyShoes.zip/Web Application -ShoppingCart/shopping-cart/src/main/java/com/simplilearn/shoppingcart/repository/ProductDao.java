package com.simplilearn.shoppingcart.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.simplilearn.shoppingcart.models.Product;

public interface ProductDao extends JpaRepository<Product, Long> {

	Product findByName(String name);

//	List<Product> findAllById(List<Long> id);

//	public  long count();
//	public List<Product> findAllByPrice(Sort sort);
//	public List<Product> findAllByName(Sort sort);
}
