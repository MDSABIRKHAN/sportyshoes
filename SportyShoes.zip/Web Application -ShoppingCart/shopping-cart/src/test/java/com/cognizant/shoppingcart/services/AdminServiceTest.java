package com.cognizant.shoppingcart.services;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import com.simplilearn.shoppingcart.models.Cart;
import com.simplilearn.shoppingcart.models.Product;
import com.simplilearn.shoppingcart.models.PurchaseRecord;
import com.simplilearn.shoppingcart.models.User;
import com.simplilearn.shoppingcart.repository.ProductDao;
import com.simplilearn.shoppingcart.services.AdminService;
import com.simplilearn.shoppingcart.services.UserService;

@SpringBootTest
class AdminServiceTest {

	@Autowired
	AdminService adminService;

	@Autowired
	UserService userService;
	
	@Autowired
	ProductDao productDao;

	@BeforeEach
	public void initializeData() {
		/*
		 * insert into product(id,name,category,price,image) values(1000,'MacBook
		 * Pro','Laptop',120000,'1000.jpg');
		 * 
		 * insert into product(id,name,category,price,image)
		 * values(1001,'IPad','Tablet',100000,'1001.jpg');
		 * 
		 * insert into product(id,name,category,price,image) values(1002,'IPhone
		 * 12','SmartPhone',90000,'1002.jpg');
		 */
		userService.saveCart(new Cart(0L, 1000L, "MacBookPro", new BigDecimal(120000L)));
		userService.saveCart(new Cart(0L, 1001L, "IPad", new BigDecimal(100000)));
		userService.saveCart(new Cart(0L, 1002L, "IPhone 12", new BigDecimal(90000)));
		List<Cart> cart = userService.getCart(0L);
		BigDecimal totalPrice = userService.getTotal(cart);
		PurchaseRecord purchaseRecord1 = new PurchaseRecord(0l, totalPrice);
		PurchaseRecord purchaseRecord2 = new PurchaseRecord(0l, totalPrice);
		purchaseRecord1.setProducts(userService.getProductsFromCart(cart));
		purchaseRecord2.setProducts(userService.getProductsFromCart(cart));
		userService.savePurchase(purchaseRecord1);
		userService.savePurchase(purchaseRecord2);
		purchaseRecord1 = userService.getRecordById(4000000L);
//		System.out.println(purchaseRecord1.getConfirmationNumber());
		purchaseRecord2 = userService.getRecordById(4000001L);
		System.out.println("Data Initialized");
	}

	@Test
	public void test_getAllUsers() {
		List<User> allUsers = adminService.getAllUsers();
		System.out.println(allUsers.toString());
		assertNotNull(allUsers.toString());
	}

	@Test
	public void test_productData() {
		Page<Product> products = userService.getAllProducts(1, 3, "name", "asc");
		assertEquals(3, products.getSize());
		assertEquals("IPad", products.getContent().get(0).getName());
		assertEquals("MacBook Pro", userService.getAllProducts(1, 3, "name", "dsc").getContent().get(0).getName());
		assertEquals(0, new BigDecimal(60000)
				.compareTo(userService.getAllProducts(1, 3, "price", "asc").getContent().get(0).getPrice()));
		assertEquals(0, new BigDecimal(150000)
				.compareTo(userService.getAllProducts(1, 3, "price", "dsc").getContent().get(0).getPrice()));

	}

	@Test
	public void test_update_Account_status() {
		boolean status = false;
		adminService.lockAccount("bparag99@gmail.com");
		status = userService.getUser("bparag99@gmail.com").getIsLocked();
		assertFalse(status);
		adminService.updateAccount(0L);
		status = userService.getUser("bparag99@gmail.com").getIsLocked();
		assertTrue(status);
	}

	@Test
	public void test_purchaseHistory() {
		List<PurchaseRecord> list = userService.getPurchaseHistoryForUser(0L);
		assertNotNull(list.toString());
		assertEquals(4000000L, list.get(0).getConfirmationNumber());

	}

	@Test
	public void test_getPurchaseRecord() {
		PurchaseRecord purchaseRecord = userService.getRecordById(4000000L);
		System.out.println(purchaseRecord.toString());
		assertNotNull(purchaseRecord);
		assertEquals(4000000L, purchaseRecord.getConfirmationNumber());
	}

	@Test
	public void test_export() throws Exception {

		ByteArrayInputStream in = adminService.exportProducts();
		assertNotNull(in);
	}

	@Test
	public void test_addNewProduct() throws Exception {

		Product product = new Product("Samsung S20", new BigDecimal(70000L), "SmartPhone");
		product.setCategory(product.getCategory());
		product.setId(product.getId());
		product.setPrice(product.getPrice());
		product.setImage(product.getImage());
		product.setName(product.getName());
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		InputStream input = classLoader.getResourceAsStream("image.jpg");
		String fileItem = "image.jpg";
		MultipartFile multipartFile = new MockMultipartFile(fileItem, input);
		adminService.addNewProduct(product ,multipartFile);
		Product product2 = productDao.findByName("Samsung S20");
		assertTrue(product.getName().equalsIgnoreCase(product2.getName()));

	}
}
