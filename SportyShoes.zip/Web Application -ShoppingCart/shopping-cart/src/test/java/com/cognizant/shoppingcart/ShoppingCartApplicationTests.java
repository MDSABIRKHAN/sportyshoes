package com.cognizant.shoppingcart;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.web.multipart.MultipartFile;

import com.simplilearn.shoppingcart.models.Cart;
import com.simplilearn.shoppingcart.models.CreditCard;
import com.simplilearn.shoppingcart.models.Product;
import com.simplilearn.shoppingcart.models.PurchaseRecord;
import com.simplilearn.shoppingcart.models.User;
import com.simplilearn.shoppingcart.repository.ProductDao;
import com.simplilearn.shoppingcart.services.AdminService;
import com.simplilearn.shoppingcart.services.UserService;

@SpringBootTest
class ShoppingCartApplicationTests {
	@Autowired
	AdminService adminService;

	@Autowired
	UserService userService;

	@Autowired
	ProductDao productDao;

	@BeforeEach
	public void initializeData() {
		/*
		 * insert into product(id,name,category,price,image) values(1000,'MacBook
		 * Pro','Laptop',120000,'1000.jpg');
		 * 
		 * insert into product(id,name,category,price,image)
		 * values(1001,'IPad','Tablet',100000,'1001.jpg');
		 * 
		 * insert into product(id,name,category,price,image) values(1002,'IPhone
		 * 12','SmartPhone',90000,'1002.jpg');
		 */

		Product product = userService.findProductById(1000L);
		userService.saveCart(new Cart(0L, product.getId(), product.getName(), product.getPrice()));
		userService.saveCart(new Cart(0L, 1001L, "IPad", new BigDecimal(100000)));
		userService.saveCart(new Cart(0L, 1002L, "IPhone 12", new BigDecimal(90000)));
		List<Cart> cart = userService.getCart(0L);
		BigDecimal totalPrice = userService.getTotal(cart);
		PurchaseRecord purchaseRecord1 = new PurchaseRecord(0l, totalPrice);
		PurchaseRecord purchaseRecord2 = new PurchaseRecord(0l, totalPrice);
		purchaseRecord1.setProducts(userService.getProductsFromCart(cart));
		purchaseRecord2.setProducts(userService.getProductsFromCart(cart));
		userService.savePurchase(purchaseRecord1);
		userService.savePurchase(purchaseRecord2);
		purchaseRecord1 = userService.getRecordById(4000000L);
//		System.out.println(purchaseRecord1.getConfirmationNumber());
		purchaseRecord2 = userService.getRecordById(4000001L);
		userService.clearCart(cart);
		System.out.println("Data Initialized");
	}

	User saveNewUser() {
		User user = new User("Parag", "Bajaj", 7869730150L, "03/06/1998", "pparag68@gmail.com");
		user.setIsLocked(false);
		userService.saveUser(user);
		return userService.getUser(user.getEmailId());

	}

	@Test
	@DirtiesContext
	public void testUpdateUser() {
		User user = saveNewUser();
		String password = user.getLastName() + "." + user.getFirstName();
		assertNotEquals(password, user.getPassword());
		user.setMobileNo(7487458745L);
		user.setIsLocked(true);
		assertEquals("03/06/1998", user.getDateOfBirth());
		User user2 = userService.save(user);
		assertEquals(7487458745L, user2.getMobileNo());
	}

	@Test
	public void test_SaveUser_duplicateUser() {
		User user = userService.getUser("bparag99@gmail.com");
		assertFalse(userService.saveUser(user));
	}
	@Test
	@DirtiesContext
	public void test_validateUser_allTrue() {
		User user = saveNewUser();
		String password = user.getLastName() + "." + user.getFirstName();
		user.setPassword(password);
		assertTrue(userService.validateUser(user));
		user.setIsLocked(true);
		user = userService.save(user);
		assertFalse(userService.validateUser(user));
		user.setPassword("password");
		assertFalse(userService.validateUser(user));
		user = new User(" ", "", 8874555L, "03-11-4554", "bparag99@gmail.com");
		assertFalse(userService.validateUser(user));

	}
	
	@Test
	public void testGetAllProducts() {
		Page<Product> products = userService.getAllProducts(1, 3, "name", "asc");
		assertEquals(3, products.getSize());
		assertEquals("IPad", products.getContent().get(0).getName());
		assertEquals("MacBook Pro", userService.getAllProducts(1, 3, "name", "dsc").getContent().get(0).getName());
		assertEquals(0, new BigDecimal(60000)
				.compareTo(userService.getAllProducts(1, 3, "price", "asc").getContent().get(0).getPrice()));
		assertEquals(0, new BigDecimal(150000)
				.compareTo(userService.getAllProducts(1, 3, "price", "dsc").getContent().get(0).getPrice()));
	}
	@Test
	public void testGetPurchaseHistoryAndRecord() {
		Page<PurchaseRecord> page = userService.getPurchaseHistoryForUser(0l, 1, 3, "confirmationNumber", "asc");
		assertEquals(3, page.getSize());
		assertEquals(4000000L, page.getContent().get(0).getConfirmationNumber());
		assertEquals(4000003L, userService.getPurchaseHistoryForUser(0l, 1, 3, "confirmationNumber", "dsc").getContent().get(0).getConfirmationNumber());
//		assertEquals(4000000L, userService.getPurchaseHistoryForUser(0l, 1, 3, "confirmationNumber", "dsc").getContent().get(0).getConfirmationNumber());
		PurchaseRecord purchaseRecord = userService.getRecordById(4000000L);
		assertEquals(4000000L, purchaseRecord.getConfirmationNumber());
	}
	@Test
	public void testCreditCard() {
		CreditCard saveCreditCard = userService.saveCreditCard(new CreditCard("Parag Bajaj", 145784512333L, 12, 2020, 564));
		System.out.println(saveCreditCard.getCcNumber());
		saveCreditCard.setCcNumber(5000720014639381L);
		System.out.println(userService.validateCC(saveCreditCard));
		assertNotNull(saveCreditCard.toString());
//		assertEquals(saveCreditCard.getCcNumber(), saveCreditCard.getCcNumber());
//		assertEquals(saveCreditCard.getCvv(), saveCreditCard.getCvv());
//		assertEquals(saveCreditCard.getId(), saveCreditCard.getId());
//		assertEquals(saveCreditCard.getMonth(), saveCreditCard.getMonth());
//		assertEquals(saveCreditCard.getYear(), saveCreditCard.getYear());
//		assertEquals(saveCreditCard.getName(), saveCreditCard.getName());
	}
	@Test
	public void testExport() throws IOException {
		List<PurchaseRecord> purchaseHistory = userService.getPurchaseHistoryForUser(0l);
		ByteArrayInputStream in = userService.getPurchaseHistory(purchaseHistory);
		assertNotNull(in);
		purchaseHistory.clear();
		in = userService.getPurchaseHistory(purchaseHistory);
		assertNotNull(in);
	}
	@Test
	public void test_removeItem() throws IOException {
		userService.saveCart(new Cart(0L, 1001L, "IPad", new BigDecimal(100000)));
		List<Cart> cart = userService.getCart(0L);
		System.out.println(cart.toString());
		userService.removeItem(3003L);
	}
	@Test
	public void test_uploadImage() throws IOException {
		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		InputStream input = classLoader.getResourceAsStream("image.jpg");
		String fileItem = "image.jpg";
		MultipartFile multipartFile = new MockMultipartFile(fileItem, input);
		String uploadImage = adminService.uploadImage(multipartFile);
		assertNotNull(uploadImage);
		
	}
	
	
	/*
	 * saveUser generatePassword validateUser checkPassword findProductById
	 * saveCreditCard clearCart getPurchaseHistoryForUser(Long id, int pageNo, int
	 * recordPerPage, String sortField, String sortDir) sendmail
	 * getPurchaseHistory(List<PurchaseRecord> purchaseHistory) removeItem save(User
	 * user)
	 */

}
